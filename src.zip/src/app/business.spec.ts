import { Business } from './business';

describe('Business', () => {
  it('should create an instance', () => {
    expect(new Business()).toBeTruthy();
  });
});
