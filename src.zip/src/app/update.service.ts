import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Delivery } from './delivery';



@Injectable({
  providedIn: 'root'
})
export class UpdateService {

  prod: Observable<Delivery>;

  constructor(private httpClient: HttpClient) { }

  public proStatus(ordId): Observable<Delivery> {

    return this.httpClient.get<Delivery>("http://localhost:8083/get/" + ordId);
  }

}