import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RemoveMerchantComponent } from './remove-merchant.component';

describe('RemoveMerchantComponent', () => {
  let component: RemoveMerchantComponent;
  let fixture: ComponentFixture<RemoveMerchantComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RemoveMerchantComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RemoveMerchantComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
