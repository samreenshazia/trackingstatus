import { Component, OnInit } from '@angular/core';
import { UpdateService } from '../update.service';
import { Delivery } from '../delivery';



@Component({
  selector: 'app-status',
  templateUrl: './status.component.html',
  styleUrls: ['./status.component.css']
})
export class StatusComponent implements OnInit {

  constructor(private updateService: UpdateService) { }

  tracking: Delivery;

  ngOnInit() {
    this.tracking = new Delivery();
  }
  check(data) {
    this.updateService.proStatus(data.ordId).subscribe(data => this.tracking = data);
    console.log(data);

  }
}