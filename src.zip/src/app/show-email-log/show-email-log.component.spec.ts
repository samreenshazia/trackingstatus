import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowEmailLogComponent } from './show-email-log.component';

describe('ShowEmailLogComponent', () => {
  let component: ShowEmailLogComponent;
  let fixture: ComponentFixture<ShowEmailLogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowEmailLogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowEmailLogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
